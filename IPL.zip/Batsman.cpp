#include "Batsman.h"
#include <iomanip>

int Batsman::getNoOfBallsFaced()
{
   //Fill the code here
}

void Batsman::setNoOfBallsFaced(int noOfBallsFaced)
{
    //Fill the code here
}

int Batsman::getTotalRunsScored()
{
    //Fill the code here
}

void Batsman::setTotalRunsScored(int totalRunsScored)
{
    //Fill the code here
}
void Batsman::displayBattingStrikeRate(Batsman b)
{
    //Fill the code here
}

