#include "Bowler.h"

int Bowler::getNoOfOversBowled()
{
    //Fill the code here
}

void Bowler::setNoOfOversBowled(int noOfOversBowled)
{
   //Fill the code here
}

int Bowler::getNoOfWicketsScored()
{
    //Fill the code here
}

void Bowler::setNoOfWicketsScored(int noOfWicketsScored)
{
    //Fill the code here
}


void Bowler::displayBowlingStrikeRate(Bowler b)
{
   //Fill the code here
}
