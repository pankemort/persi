#include <iostream>
#include <string>
#include "Player.h"
using namespace std;
class Batsman :public Player {
private:
    //Fill the code here
public:
    int getNoOfBallsFaced();

    void setNoOfBallsFaced(int noOfBallsFaced);
    int getTotalRunsScored();

    void setTotalRunsScored(int totalRunsScored);
    void displayBattingStrikeRate(Batsman b);
};