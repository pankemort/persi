#include <iostream>
#include<string>
#include<stdio.h>
using namespace std;
int main()
{
   //Fill the code here
}