#include "Player.h"

string Player::getCountry()
{
   //Fill the code here
}

void Player::setCountry(string country)
{
   //Fill the code here
}

string Player::getPlayerName()
{
    //Fill the code here
}

void Player::setPlayerName(string playerName)
{
    //Fill the code here
}
