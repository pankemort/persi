#include <iostream>
#include <string>
using namespace std;
class Player {
private:
    //Fill the code here
public:
    string getCountry();

    void setCountry(string country);
    string getPlayerName();

    void setPlayerName(string playerName);
};