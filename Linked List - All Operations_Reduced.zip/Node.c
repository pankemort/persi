#include <stdio.h>
#include <stdlib.h>
#include "Node.h"

struct Node* createNode(int data) {
    //Fill your code here
}

struct Node* insertNode(struct Node* head, int data) {
    //Fill your code here
}

void deleteNode(struct Node* head, int data) {
    //Fill your code here
}

void searchNode(struct Node* head, int data) {
    //Fill your code here
}

void updateNode(struct Node* head, int key, int newValue) {
    //Fill your code here
}

void sort(struct Node* head) {
    //Fill your code here
}

void displayList(struct Node* head) {
    //Fill your code here
}

int findMin(struct Node* head) {
    //Fill your code here
    return 0;
}

int findMax(struct Node* head) {
    //Fill your code here
    return 0;
}

int findMid(struct Node* head) {
    //Fill your code here
    return 0;
}